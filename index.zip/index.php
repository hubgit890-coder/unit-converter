<?php 
include("header.html");
include("middle.html");
include("footer.html");
?>